import{a as t}from"../chunks/entry.7AO_ebvG.js";export{t as start};
