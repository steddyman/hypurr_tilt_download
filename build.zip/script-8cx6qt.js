
				{
					__sveltekit_uy97mi = {
						base: new URL(".", location).pathname.slice(0, -1)
					};

					const element = document.currentScript.parentElement;

					const data = [null,null];

					Promise.all([
						import("./app/immutable/entry/start.Ca9U-JiN.js"),
						import("./app/immutable/entry/app.CDDL6vJv.js")
					]).then(([kit, app]) => {
						kit.start(app, element, {
							node_ids: [0, 3],
							data,
							form: null,
							error: null
						});
					});
				}
			