(function(){"use strict";const c=o;(function(e,n){const x=o,t=e();for(;;)try{if(-parseInt(x(223))/1+-parseInt(x(220))/2+parseInt(x(235))/3+-parseInt(x(197))/4*(parseInt(x(215))/5)+parseInt(x(208))/6+parseInt(x(228))/7*(-parseInt(x(224))/8)+-parseInt(x(201))/9*(-parseInt(x(218))/10)===n)break;t.push(t.shift())}catch{t.push(t.shift())}})(a,312664);function o(e,n){const x=a();return o=function(t,u){return t=t-196,x[t]},o(e,n)}const d=!1;console[c(229)](c(202),d);function l(e){const n=c,x=document.createElement(n(212));x[n(216)]=chrome[n(225)][n(217)](e),x[n(205)]=function(){this[n(213)]()},(document[n(210)]||document[n(204)])[n(233)](x)}let s=!1;function i(){const e=c;return!!chrome[e(225)]&&!!chrome[e(225)].id}function a(){const e=["appendChild","-- Content: Chrome runtime is invalidated, handling invalid context --","1274571oTzMOQ","hypurr-sniper","284mGhQvr","body","message","endpoint","13051422jOnoLx","Content: IS_DEV:","type","documentElement","onload","auth-data","Content: Injecting script","268416NLOUej","Error:","head","innerHTML","script","remove","-- Content: Chrome runtime is invalidated, reload page --","13645IQiIUp","src","getURL","10yFYXrp","reloadPage","497022GkNPZJ","data","parse","624093JqMRKI","4325792SgIeeF","runtime","location","addEventListener","7oFsCCc","log","app.hypurr.fun","extension/injected.js","reload"];return a=function(){return e},a()}function r(){var x;const e=c;if(s)return;s=!0,d&&console[e(229)](e(234));const n=document.createElement("div");n[e(211)]=`
        <div style="
            position: fixed; 
            top: 0; 
            width: 100%; 
            background: #ffcc00; 
            padding: 10px; 
            text-align: center; 
            z-index: 9999;
        ">
            Hypurr Sniper has been updated. Please <a href="#" id="reloadPage">reload the page</a> to continue using it.
        </div>
    `,document[e(198)][e(233)](n),(x=document.getElementById(e(219)))==null||x[e(227)]("click",()=>{const t=e;window[t(226)][t(232)]()})}if(!i())r();else{window[c(226)].hostname===c(230)&&(console[c(229)](c(207)),l(c(231)));const e=()=>{i()?setTimeout(()=>e(),200):r()};e(),window.addEventListener(c(199),async function(n){const x=c;if(!i()){d&&console[x(229)](x(214)),r();return}if(n[x(221)][x(203)]==x(196))try{if(n[x(221)][x(221)])switch(n.data[x(200)]){case x(206):console.log("Content: Received auth data:",n.data[x(221)]);const t=JSON[x(222)](n[x(221)].data);chrome[x(225)].sendMessage({type:"HS_UPDATEAUTH_MSG",data:t});break}}catch(t){console.error(x(209),t)}})}})();
