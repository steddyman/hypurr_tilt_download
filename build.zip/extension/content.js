(function(){"use strict";const a=o;function o(e,n){const x=i();return o=function(t,u){return t=t-370,x[t]},o(e,n)}(function(e,n){const x=o,t=e();for(;;)try{if(parseInt(x(388))/1*(parseInt(x(382))/2)+parseInt(x(396))/3+-parseInt(x(395))/4*(parseInt(x(372))/5)+parseInt(x(378))/6*(-parseInt(x(394))/7)+-parseInt(x(405))/8*(-parseInt(x(402))/9)+parseInt(x(401))/10+parseInt(x(371))/11===n)break;t.push(t.shift())}catch{t.push(t.shift())}})(i,171128);const c=!1;console[a(404)]("Content: IS_DEV:",c);function i(){const e=["extension/injected.js","endpoint","-- Content: Chrome runtime is invalidated, reload page --","app.hypurr.fun","auth-data","12873ZBcDQy","4fzQMej","78954FAbhTU","-- Content: Chrome runtime is invalidated, handling invalid context --","innerHTML","type","body","1746100qEefBi","2702637YilfDp","head","log","8VyOUNi","sendMessage","appendChild","2129457eoDDbv","1596365HUVlKy","location","error","data","onload","addEventListener","780ZCnwHX","getURL","runtime","hostname","2ndpYYd","Error:","createElement","click","reload","hypurr-sniper","34663EYycJO"];return i=function(){return e},i()}function l(e){const n=a,x=document[n(384)]("script");x.src=chrome[n(380)][n(379)](e),x[n(376)]=function(){this.remove()},(document[n(403)]||document.documentElement)[n(370)](x)}let s=!1;function d(){const e=a;return!!chrome[e(380)]&&!!chrome[e(380)].id}function r(){var x;const e=a;if(s)return;s=!0,c&&console.log(e(397));const n=document.createElement("div");n[e(398)]=`
        <div style="
            position: fixed; 
            top: 0; 
            width: 100%; 
            background: #ffcc00; 
            padding: 10px; 
            text-align: center; 
            z-index: 9999;
        ">
            Hypurr Sniper has been updated. Please <a href="#" id="reloadPage">reload the page</a> to continue using it.
        </div>
    `,document[e(400)].appendChild(n),(x=document.getElementById("reloadPage"))==null||x[e(377)](e(385),()=>{const t=e;window[t(373)][t(386)]()})}if(!d())r();else{window[a(373)][a(381)]===a(392)&&(console[a(404)]("Content: Injecting script"),l(a(389)));const e=()=>{d()?setTimeout(()=>e(),200):r()};e(),window[a(377)]("message",async function(n){const x=a;if(!d()){c&&console[x(404)](x(391)),r();return}if(n[x(375)][x(399)]==x(387))try{if(n.data.data)switch(n.data[x(390)]){case x(393):console[x(404)]("Content: Received auth data:",n[x(375)][x(375)]);const t=JSON.parse(n.data[x(375)]);chrome.runtime[x(406)]({type:"HS_UPDATEAUTH_MSG",data:t});break}}catch(t){console[x(374)](x(383),t)}})}})();
