(function(){"use strict";const a=c;(function(n,e){const x=c,t=n();for(;;)try{if(-parseInt(x(160))/1+-parseInt(x(150))/2+-parseInt(x(155))/3+parseInt(x(163))/4+-parseInt(x(135))/5*(-parseInt(x(159))/6)+parseInt(x(153))/7*(parseInt(x(147))/8)+-parseInt(x(148))/9===e)break;t.push(t.shift())}catch{t.push(t.shift())}})(o,366123);const i=!1;function o(){const n=["endpoint","hypurr-sniper","documentElement","head","Error:","24apkjOF","2692368Fbnrlf","reload","242324ELXnnu","hostname","-- Content: Chrome runtime is invalidated, reload page --","1556058GEIlYg","log","1914600cxuXdZ","createElement","HS_UPDATEAUTH_MSG","script","56982pGwLVL","16153pvgLIt","sendMessage","data","2069956lZrxec","src","error","location","-- Content: Chrome runtime is invalidated, handling invalid context --","runtime","getElementById","addEventListener","click","remove","Content: IS_DEV:","135HYoNDW","Content: Injecting script","appendChild","message","reloadPage","innerHTML","onload"];return o=function(){return n},o()}console[a(154)](a(134),i);function u(n){const e=a,x=document[e(156)](e(158));x[e(164)]=chrome[e(168)].getURL(n),x[e(141)]=function(){this[e(133)]()},(document[e(145)]||document[e(144)]).appendChild(x)}function c(n,e){const x=o();return c=function(t,l){return t=t-131,x[t]},c(n,e)}let d=!1;function s(){const n=a;return!!chrome[n(168)]&&!!chrome[n(168)].id}function r(){var x;const n=a;if(d)return;d=!0,i&&console[n(154)](n(167));const e=document[n(156)]("div");e[n(140)]=`
        <div style="
            position: fixed; 
            top: 0; 
            width: 100%; 
            background: #ffcc00; 
            padding: 10px; 
            text-align: center; 
            z-index: 9999;
        ">
            The Tilt extension has been updated. Please <a href="#" id="reloadPage">reload the page</a> to continue using it.
        </div>
    `,document.body[n(137)](e),(x=document[n(169)](n(139)))==null||x.addEventListener(n(132),()=>{const t=n;window[t(166)][t(149)]()})}if(!s())r();else{window.location[a(151)]==="app.hypurr.fun"&&(console.log(a(136)),u("extension/injected.js"));const n=()=>{s()?setTimeout(()=>n(),200):r()};n(),window[a(131)](a(138),async function(e){const x=a;if(!s()){i&&console[x(154)](x(152)),r();return}if(e[x(162)].type==x(143))try{if(e[x(162)][x(162)])switch(e[x(162)][x(142)]){case"auth-data":console[x(154)]("Content: Received auth data:",e[x(162)][x(162)]);const t=JSON.parse(e[x(162)][x(162)]);chrome[x(168)][x(161)]({type:x(157),data:t});break}}catch(t){console[x(165)](x(146),t)}})}})();
