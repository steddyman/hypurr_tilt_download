import{a as t}from"../chunks/entry.BjNbiNhj.js";export{t as start};
