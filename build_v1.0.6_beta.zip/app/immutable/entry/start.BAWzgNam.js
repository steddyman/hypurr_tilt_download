import{a as t}from"../chunks/entry.BXASK4zy.js";export{t as start};
