import{a as t}from"../chunks/entry.CJD_WeSV.js";export{t as start};
