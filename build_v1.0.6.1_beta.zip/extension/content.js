(function(){"use strict";function o(){const e=["click","createElement","getElementById","Content: IS_DEV:","sendMessage","auth-data","-- Content: Chrome runtime is invalidated, reload page --","7zWwUKU","376476mvXsZb","hostname","11517776QCvyPO","documentElement","Content: Received auth data:","reloadPage","Content: Injecting script","location","script","runtime","addEventListener","data","message","remove","5BcmqeV","onload","hypurr-sniper","9151614SPrgDs","HS_UPDATEAUTH_MSG","Error:","log","170gdooFp","getURL","innerHTML","reload","9084798uwqPhW","13330230gcGMJy","5312otlUzh","429SDoWuI","app.hypurr.fun","endpoint"];return o=function(){return e},o()}function c(e,n){const x=o();return c=function(t,f){return t=t-224,x[t]},c(e,n)}const a=c;(function(e,n){const x=c,t=e();for(;;)try{if(-parseInt(x(249))/1*(-parseInt(x(255))/2)+parseInt(x(256))/3+-parseInt(x(228))/4*(parseInt(x(242))/5)+parseInt(x(245))/6+parseInt(x(227))/7*(-parseInt(x(230))/8)+-parseInt(x(253))/9+parseInt(x(254))/10===n)break;t.push(t.shift())}catch{t.push(t.shift())}})(o,766692);const i=!1;console[a(248)](a(262),i);function u(e){const n=a,x=document[n(260)](n(236));x.src=chrome.runtime[n(250)](e),x[n(243)]=function(){this[n(241)]()},(document.head||document[n(231)]).appendChild(x)}let s=!1;function d(){return!!chrome.runtime&&!!chrome.runtime.id}function r(){var x;const e=a;if(s)return;s=!0,i&&console[e(248)]("-- Content: Chrome runtime is invalidated, handling invalid context --");const n=document[e(260)]("div");n[e(251)]=`
        <div style="
            position: fixed; 
            top: 0; 
            width: 100%; 
            background: #ffcc00; 
            padding: 10px; 
            text-align: center; 
            z-index: 9999;
        ">
            The Tilt extension has been updated. Please <a href="#" id="reloadPage">reload the page</a> to continue using it.
        </div>
    `,document.body.appendChild(n),(x=document[e(261)](e(233)))==null||x[e(238)](e(259),()=>{const t=e;window[t(235)][t(252)]()})}if(!d())r();else{window[a(235)][a(229)]===a(257)&&(console[a(248)](a(234)),u("extension/injected.js"));const e=()=>{d()?setTimeout(()=>e(),200):r()};e(),window[a(238)](a(240),async function(n){const x=a;if(!d()){i&&console.log(x(226)),r();return}if(n[x(239)].type==x(244))try{if(n.data[x(239)])switch(n[x(239)][x(258)]){case x(225):console[x(248)](x(232),n[x(239)][x(239)]);const t=JSON.parse(n[x(239)][x(239)]);chrome[x(237)][x(224)]({type:x(246),data:t});break}}catch(t){console.error(x(247),t)}})}})();
