(function(){"use strict";console.log("Content: IS_DEV:",!1);function d(t){const e=document.createElement("script");e.src=chrome.runtime.getURL(t),e.onload=function(){this.remove()},(document.head||document.documentElement).appendChild(e)}let a=!1;function n(){return!!chrome.runtime&&!!chrome.runtime.id}function o(){var e;if(a)return;a=!0;const t=document.createElement("div");t.innerHTML=`
        <div style="
            position: fixed; 
            top: 0; 
            width: 100%; 
            background: #ffcc00; 
            padding: 10px; 
            text-align: center; 
            z-index: 9999;
        ">
            The Tilt extension has been updated. Please <a href="#" id="reloadPage">reload the page</a> to continue using it.
        </div>
    `,document.body.appendChild(t),(e=document.getElementById("reloadPage"))==null||e.addEventListener("click",()=>{window.location.reload()})}if(!n())o();else{window.location.hostname==="app.hypurr.fun"&&(console.log("Content: Injecting script"),d("extension/injected.js"));const t=()=>{n()?setTimeout(()=>t(),200):o()};t(),window.addEventListener("message",async function(e){if(!n()){o();return}if(e.data.type=="hypurr-sniper")try{if(e.data.data)switch(e.data.endpoint){case"auth-data":console.log("Content: Received auth data:",e.data.data);const i=JSON.parse(e.data.data);chrome.runtime.sendMessage({type:"HS_UPDATEAUTH_MSG",data:i});break}}catch(i){console.error("Error:",i)}})}})();
