(function(){"use strict";let t={};setInterval(()=>{const e=localStorage.getItem("telegramAuth");e!==t&&(t=e,window.postMessage({type:"hypurr-sniper",endpoint:"auth-data",data:e},"*"))},1e3)})();
