import{a as t}from"../chunks/entry.D65bB_hd.js";export{t as start};
